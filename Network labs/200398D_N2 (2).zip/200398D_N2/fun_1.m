function Received_code = fun_1(codeword,probability)  %function to create
    codeword = dec2bin(codeword);
    codeword = num2cell(codeword);
    codeword = str2double( codeword);

    received= bsc(codeword,probability);
    
    received = num2str(received);
    received = received(~isspace(received));
    received = bin2dec(received);
   

    Received_code=received;