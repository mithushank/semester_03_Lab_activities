function syndrome = fun_3(received)      %function to check the syndrome
   divisor = 0b10111u32;
   codeLength = strlength( dec2bin(received) );
    divisorDegree = strlength( dec2bin(divisor) ) -1;
    divisor = bitshift(divisor,codeLength-divisorDegree-1);
    remainder = received;
    for k = 1:(codeLength-divisorDegree)
        if bitget(remainder,codeLength)
                    remainder = bitxor(remainder,divisor);
        end
        remainder = bitshift(remainder,1);
        
    end
    syndrome = bitshift(remainder,-(codeLength-divisorDegree));