function syndrome = fun_4(dataword,probability)
    codeword = fun_2(dataword);
    received= fun_1(codeword,probability);
    syndrome = fun_3(received);
