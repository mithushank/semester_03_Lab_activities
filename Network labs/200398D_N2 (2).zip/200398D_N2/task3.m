codeword= 0b1010011110101u32;
divisor = 0b10111u32;
transmitted=codeword;

codeword=dec2bin(codeword);
codeword=num2cell(codeword);
codeword = str2double(codeword);

probability=0.5;

received= bsc(codeword,probability);
received = num2str(received);
received = received(~isspace(received));
received = bin2dec(received);
disp("tranmistted is "+ dec2bin(transmitted));
disp("receiced is    "+ dec2bin(received ));



syndrome = decode_1(received, divisor);
disp("syndrome at receiver = " + dec2bin(syndrome));