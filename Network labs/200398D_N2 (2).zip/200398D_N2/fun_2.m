function encode = fun_2(message)
    divisor_ini= 0b10111u32;
    divisor=divisor_ini;
    messageLength = strlength( dec2bin(message) );
    divisorDegree = strlength( dec2bin(divisor) ) -1;
    divisor = bitshift(divisor,messageLength-1);
 
    remainder = bitshift(message,divisorDegree);
   
    for k = 1:messageLength
        if bitget(remainder,messageLength+divisorDegree)
                    remainder = bitxor(remainder,divisor);
        end
        remainder = bitshift(remainder,1);
    end
    
    CRC_check_value = bitshift(remainder,-messageLength);
    output = bitshift(message,divisorDegree);
    output = bitor(output,CRC_check_value);
   

    encode=output;
