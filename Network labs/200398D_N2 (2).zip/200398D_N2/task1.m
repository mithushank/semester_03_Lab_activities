message = 0b101001111u32;
divisor = 0b10111u32;

messageLength=strlength (dec2bin(message));
divisorDegree = strlength (dec2bin(divisor))-1;


divisor = bitshift(divisor,messageLength-1);
remainder = bitshift(message,divisorDegree);

    for k = 1:messageLength
        if bitget(remainder,messageLength+divisorDegree)
             remainder = bitxor(remainder,divisor);
        end
        remainder = bitshift(remainder,1);
    end


CRC_check_value = bitshift(remainder,-messageLength);
newmessage=bitshift(message,divisorDegree);

codeword=bitor(newmessage,CRC_check_value);

disp("your codeword is "+ dec2bin(codeword))





