codeword= 0b1010011110101u32;
divisor = 0b10111u32;

codelength=strlength(dec2bin(codeword));
divisordegree = strlength(dec2bin(divisor))-1;


remainder=codeword;
divisor=bitshift(divisor,(codelength-divisordegree-1));
for k = 1:(codelength-divisordegree)
    if bitget(remainder,codelength)
        remainder = bitxor(remainder,divisor);
    end
    remainder = bitshift(remainder,1);
end
syndrome=bitshift(remainder,-(codelength-divisordegree));
disp("syndrome  "+ dec2bin(syndrome))
if syndrome == 0
    disp('Message is error free.')
else
    disp('Message contains errors.')
end