datawords = randi(511, 1, 10000);  %511 for create a 9bit dataword

prob_values = [0.5 0.4 0.3 0.2 0.1 0.01 0.001 0.0001];
error_rates = zeros(1, length(prob_values));

for m = 1:length(prob_values)
    error_no = 0;
   
    for k = 1:10000
        syndrome = fun_4(datawords(k), prob_values(m));
        if syndrome ~= 0
            error_no = error_no + 1;
        end
    end
    error_rates(m) = error_no/10000;
    fprintf("Error probability = %f, Error rate = %f\n", prob_values(m), error_no/10000);
end

plot(prob_values, error_rates);

